# Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sirma/pen/WNdBVBW](https://codepen.io/Sirma/pen/WNdBVBW).

